<?php

/* Define username and password */
$Username = "Steve";
$Password = "pass";
